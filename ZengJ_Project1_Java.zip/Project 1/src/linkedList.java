

public class linkedList {
   public class listNode {
      String data;
      listNode next;
   
      public listNode(String d){
         data=d;
         next=null;
      }
      
      public listNode(String d, listNode n){
         data=d;
         next=n;
      }
   }
   
   private int size=0;
   private listNode listHead;
   public linkedList(){
      listHead=new listNode("dummy", null);
   }

   public boolean isEmpty(){
      return size==0;
   }
   
   public void listInsert(String s) {
      listNode newElement= new listNode(s);
      listNode walker1=listHead;
      listNode walker2=listHead.next;
      while((walker1.next!=null)&&((walker2.data.compareTo(s))<0)){
         walker1=walker1.next;
         walker2=walker2.next;
      }
      if(listHead.next==null){
         newElement.next=walker2;
         walker1.next=newElement;
      }
      else{
         newElement.next=walker2;
         walker1.next=newElement;
      }
      size++;
   }
   
   public String printList(){
      listNode p=listHead;
      String s="";
      for(int i=0; i<15; i++){
         if(p.next!=null){
             s+="-->(" + p.data +", " + p.next.data + ")";
             p=p.next;
         }
      }
      if(p.next==null)
         s+="-->(" + p.data +", " + p.next +")";
      return s;
   }
}
