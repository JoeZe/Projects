import java.io.*;
import java.util.Scanner;
public class Project1 {
   public static void main(String[] args){
      linkedList list=new linkedList();
      System.out.println("listHead" +list.printList());
      try {
         Scanner inFile= new Scanner(new FileReader(args[0]));  //pass "insertionSort_String_Data.txt" into the program argument to run the program
         while(inFile.hasNext()){
            String s=inFile.next();
            System.out.println("Insert(" + s +"):");
            list.listInsert(s);
            System.out.println("listHead" +list.printList());
         }
         inFile.close();
         
      } catch (FileNotFoundException e) {
         // TODO Auto-generated catch block
         
         e.printStackTrace();
      }catch (IndexOutOfBoundsException e){
         e.printStackTrace();

      }
   }
}
