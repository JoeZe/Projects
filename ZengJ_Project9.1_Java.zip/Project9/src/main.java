import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class main {
   public static void main(String[] args) throws IOException{
      int n, Ni, Nj;
      try {
         Scanner inFile=new Scanner(new FileReader(args[0]));
         FileWriter outPut1=new FileWriter(args[1]);
         n=inFile.nextInt();
         graphColoring graph=new graphColoring(n);
         while(inFile.hasNext()){
            Ni=inFile.nextInt();
            Nj=inFile.nextInt();
            graph.loadMatrix(Ni, Nj);

            
         }
         graph.constructNodeList();
         graph.printAdjacencyMatrix(outPut1);
         
         while(graph.findUncolorNode().color==0){
            node currentNode =graph.findUncolorNode();
            int newColor=0;           
            while(currentNode!=null){
               newColor++;             
               if(currentNode.color==0&&graph.checkAdjacent(currentNode.ID, newColor)==0){
                  graph.adjacencyMatrix[currentNode.ID][currentNode.ID]=newColor;
                  currentNode.color=newColor;
                  newColor=0;
                  currentNode=currentNode.next;
               }               
               //if(currentNode==null&&graph.countUnColorNode()==1)
                  //currentNode=graph.findUncolorNode();
               graph.printAdjacencyMatrix(outPut1);
            }
            //graph.printList();
         }
         graph.printNewColor(outPut1);
         graph.printAdjacencyMatrix(outPut1);
         inFile.close();
         outPut1.close();
       
      } catch (FileNotFoundException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }
}
