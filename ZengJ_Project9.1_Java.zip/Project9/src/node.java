
public class node {
   int ID, color=0, numEdges=0;
   node next;
   
   public node(){

   }
   
   public node(int i, int color, int numEdge) {
      ID=i;
      this.color=color;
      this.numEdges=numEdge;
   }
}
