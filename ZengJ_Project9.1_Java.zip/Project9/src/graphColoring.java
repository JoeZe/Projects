import java.io.FileWriter;
import java.io.IOException;

public class graphColoring {
   node listHead;
   int[][] adjacencyMatrix;
   int numNode, newColor=0, uncolorNode=0;

   public graphColoring(int n) {
      numNode=n;
      adjacencyMatrix=new int[n+1][n+1];
      listHead=new node();
      for(int i=1; i<=numNode; i++){
         for(int j=1; j<=numNode; j++){
            adjacencyMatrix[i][j]=0;
         }
      }
      
   }

   public void loadMatrix(int ni, int nj) {
      adjacencyMatrix[ni][nj]=1;
      adjacencyMatrix[nj][ni]=1;
   }
   
   public void insertOneNode(node listHead, node newNode){
      node walker1 =listHead;
      node walker2 = listHead.next;
      while ((walker1.next != null) && (walker2.numEdges<newNode.numEdges)) {
         walker1 = walker1.next;
         walker2 = walker2.next;
      }
      newNode.next = walker2;
      walker1.next = newNode; 
   }
   
   public void constructNodeList(){
      int numEdge=0;
      for(int i=1; i<=numNode; i++){
         for(int j=1; j<=numNode; j++){
            if(adjacencyMatrix[i][j]==1&&adjacencyMatrix[j][i]==1)
               numEdge++;
            
         }
         node newNode=new node(i, 0, numEdge);
         insertOneNode(listHead, newNode);
         numEdge=0;
      }
    
        
   }
   
   public node findUncolorNode(){
      node walker1 =listHead.next;
      while (walker1.next != null) {
         if(walker1.color==0){
            return walker1;
         }
         else
            walker1 = walker1.next;
      }
      return walker1;

   }
   
   public int checkAdjacent(int nodeId, int color){
      int used = 0;
      for (int i = 1; i <= numNode; i++) {
          if (adjacencyMatrix[nodeId][i] == 1 &&adjacencyMatrix[i][i] != color) {
              used = 0;
          }
          if (adjacencyMatrix[nodeId][i] == 1 &&adjacencyMatrix[i][i] == color) {
              return used = 1;
          }           
      }
      return used;   
      
   }

   public void printNewColor(FileWriter outPut1) throws IOException {
      int color[] =new int[5];
      node p = listHead.next;
      while (p != null) {
          //System.out.print(p.color+ " ");
          color[p.color]++;
          p = p.next;
      }

      for(int i=1; i<color.length; i++){
         if(color[i]>0)
            newColor++;
      }
      outPut1.write("The number of colors used is: "+ newColor+"\r\n");      
   }
   
   public int countUnColorNode() {
      uncolorNode=0;
      node p = listHead.next;
      while (p != null) {
          if(p.color==0)
             uncolorNode++;
          p = p.next;
      }
      return uncolorNode;
      
   }

   public void printList() {
      node p = listHead.next;
      while (p != null) {
          System.out.println(p.ID + " "+ p.numEdges+ " " +p.color);
          p = p.next;
      }     
   }
   
   public void printAdjacencyMatrix(FileWriter outPut1) throws IOException {
      for (int i = 1; i <= numNode; i++) {
         for (int j = 1; j <= numNode; j++) 
            outPut1.write(adjacencyMatrix[i][j] +" ");        
         outPut1.write("\r\n");
     }
      outPut1.write("\r\n");
      
   }

}
