#include <iostream>
#include <string>
#include <fstream>
using namespace std;
ifstream inFile;
ofstream outFile1, outFile2;

class HeapSort {
private:
	int rootIndex, fatherIndex, leftKidIndex, rightKidIndex, minKidIndex;
	int maxsize;
public:
	int* heapAry;

	HeapSort(int count) {
		maxsize = count;
		heapAry = new int[count];
		heapAry[0] = 0;
	}

	void buildHeap() {
		int data;
		rootIndex = 1;
		while (inFile >> data) {
			insertOneDataItem(data);
			int kidIndex = heapAry[0];
			bubbleUp(kidIndex);
			outFile1 << "Inserting: " << data << endl;
			printHeap();
		}
	}

	void deleteHeap() {
		if(!isHeapEmpty())
			deleteRoot();
	}

	void insertOneDataItem(int data) {
		if (!isHeapFull()) {
			heapAry[0]++;
			heapAry[heapAry[0]] = data;
		}
	}

	int getRoot() {
		return heapAry[1];
	}

 	void deleteRoot() {
		string s = "Sorted input#:";
		while (!isHeapEmpty()) {
			int data = getRoot();
			s+= to_string(data)+ " ";
			outFile2 << s << endl;
			heapAry[1] = heapAry[heapAry[0]];
			heapAry[0]--;
			fatherIndex = rootIndex;
			bubbleDown(fatherIndex);
			outFile1 << "Removing: " << data << endl;
			printHeap();
		}
	}

	void bubbleUp(int kidIndex) {
		if (isRoot(kidIndex))
			return;
		else {
			fatherIndex = kidIndex / 2;
			if (heapAry[kidIndex] < heapAry[fatherIndex]) {
				int temp = heapAry[kidIndex];
				heapAry[kidIndex] = heapAry[fatherIndex];
				heapAry[fatherIndex] = temp;
			}
			bubbleUp(fatherIndex);
		}
	}

	void bubbleDown(int fatherIndex) {
		if (isLeaf(fatherIndex))
			return;
		else {
			leftKidIndex = fatherIndex * 2;
			rightKidIndex = fatherIndex * 2 + 1;
			if (leftKidIndex > heapAry[0])
				minKidIndex = fatherIndex;
			else if (rightKidIndex > heapAry[0])
				minKidIndex = leftKidIndex;
			else
				minKidIndex = findMinKidIndex(leftKidIndex, rightKidIndex);
			if (heapAry[fatherIndex] <= heapAry[minKidIndex])
				return;
			if (heapAry[minKidIndex] < heapAry[fatherIndex]) {
				int temp = heapAry[minKidIndex];
				heapAry[minKidIndex] = heapAry[fatherIndex];
				heapAry[fatherIndex] = temp;
			}
			bubbleDown(minKidIndex);
		}
	}

	bool isLeaf(int index) {
		return index > heapAry[0];
	}

	bool isRoot(int index) {
		return index == 1;
	}

	int findMinKidIndex(int left, int right) {
		if (heapAry[right] > heapAry[left])
			return left;
		else
			return right;
	}

	bool isHeapEmpty() {
		return heapAry[0] == 0;
	}

	bool isHeapFull() {
		return heapAry[0] == maxsize;
	}

	void printHeap() {
		int size = heapAry[0];
		for (int i = 0; i <= heapAry[0]; i++) {
				outFile1 << "___";
		}
		outFile1 << "_" << endl;
		for (int i = 0; i <= heapAry[0]; i++) {
			if(i>=10)
				outFile1 << "|" << i;
			else
				outFile1 <<"| " << i ;
		}
		outFile1 <<"|"<< endl;

		for (int i = 0; i <= heapAry[0]; i++) {
			outFile1 << "---";
		}
		outFile1 << "--" << endl;

		for (int i = 0; i <= heapAry[0]; i++) {
			if(heapAry[i]>=10)
				outFile1 << "|" << heapAry[i];
			else
				outFile1 << "| " << heapAry[i] ;
		}
		outFile1 <<"|" << endl;

		for (int i = 0; i <= heapAry[0]; i++) {
			outFile1 << "---";
		}
		outFile1 << "--" << endl;
	}
};

int main(int argc, char** argv){
	inFile.open(argv[1]);
	outFile1.open(argv[2]);
	outFile2.open(argv[3]);
	int index, count=0;
	while (inFile >> index) {
		count++;
	}
	inFile.close();
	inFile.open(argv[1]);
	HeapSort heap(count);
	heap.buildHeap();
	heap.deleteHeap();
	inFile.close();
	outFile1.close();
	outFile2.close();
	system("pause");
}