#include <iostream>
#include <fstream>
#include <string>
using namespace std;
ifstream inFile;
ofstream outFile;
class bucketSort {
public:
	int max;
	int* bucketAry;
	bucketSort(int size) {
		max = size;
		bucketAry = new int[max+1];
		for (int i = 0; i <= max; i++)
			bucketAry[i] = 0;
	}

	void insert(int data) {
		bucketAry[data]++;
	}

	void print() {	
		for (int i = 0; i <= max; i++) {
			while ( bucketAry[i]!= 0) {
				outFile << i << " ";
				bucketAry[i]--;
			}
		}
		outFile << endl;
	}
};

int main(int argc, char**argv) {
	inFile.open(argv[1]);
	outFile.open(argv[2]);
	int data, min=0, maxSize=0;
	while (inFile >> min) {
		if (maxSize < min) {
			maxSize = min;
		}
	}
	inFile.close();
	bucketSort bSort(maxSize);
	
	inFile.open(argv[1]);
	while (inFile >> data) {
		bSort.insert(data);
	}
	outFile << "Bucket Sorted: ";
	bSort.print();
	inFile.close();
	outFile.close();
}