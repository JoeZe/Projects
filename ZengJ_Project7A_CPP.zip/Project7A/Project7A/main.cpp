#include <iostream>
#include <fstream>
#include <string>
using namespace std;
ifstream inFile;
ofstream outFile1;
ofstream outFile2;
class graphNode {
public:
	int nodeId;
	graphNode* next;
	graphNode(int node) {
		nodeId = node;
		next = NULL;

	}
	graphNode() {
		delete[] next;
	}
};

class undirectedEdge {
public:
	int Ni, Nj, edgeCost;
	undirectedEdge* next;

	void printEdge() {
		string s = "";
		s += Ni + Nj + edgeCost;
	}

	undirectedEdge(int i, int j, int data) {
		Ni = i;
		Nj = j;
		edgeCost = data;
		next = NULL;
	}
	undirectedEdge() {
		delete[] next;
	}
};

class KruskalMST {
public:
	int numNodes, numSets, totalMSTCost = 0;
	int *inWhichSet;
	undirectedEdge* MSTofG;
	undirectedEdge* edgeListHead;
	graphNode *id;
	KruskalMST(int N) {
		numNodes = N;
		inWhichSet = new int[N + 1];
		numSets = N;
		MSTofG = new undirectedEdge(0, 0, 0);
		edgeListHead = new undirectedEdge(0, 0, 0);
		for (int i = 0; i <= N; i++) {
			inWhichSet[i] = 0;
		}
	}

	void insertEdge(undirectedEdge* edge, undirectedEdge* edgeListHead) {
		undirectedEdge *walker1 = edgeListHead;
		undirectedEdge *walker2 = edgeListHead->next;
		while ((walker1->next != NULL) && (walker2->edgeCost<edge->edgeCost)) {
			walker1 = walker1->next;
			walker2 = walker2->next;
		}
		edge->next = walker2;
		walker1->next = edge;
	}


	undirectedEdge* removedEdge(undirectedEdge* edgeListHead) {
		this->edgeListHead = this->edgeListHead->next;
		return edgeListHead;

	}

	void pushEdge(undirectedEdge* edge, undirectedEdge* MSTofG) {
		edge->next = MSTofG;
		this->MSTofG = edge;

	}

	void merge2Sets(int node1, int node2) {
		if (node1<node2)
			inWhichSet[node2] = node1;
		else
			inWhichSet[node1] = node2;

	}

	void printSet(int* inWhichSet) {
		outFile2 << "InWhichSet: ";
		for (int i = 1; i <= numNodes; i++)
			outFile2 << inWhichSet[i] << " ";
		outFile2 << endl;
	}

	void printMSTList(undirectedEdge* edgeListHead) {
		undirectedEdge* listHead = edgeListHead;
		int i = 1;
		while (listHead->next != NULL&&i <= 10) {
			outFile2 << "-> <" << listHead->Ni << ", " << listHead->Nj << ", " << listHead->edgeCost << "> ";
			listHead = listHead->next;
			i++;
		}
		outFile2 << "-> <" << listHead->Ni << ", " << listHead->Nj << ", " << listHead->edgeCost << "> ";
		outFile2 << endl;
	}

	void printList(undirectedEdge* edgeListHead) {
		undirectedEdge* listHead = edgeListHead;
		while (listHead->next != NULL) {
			outFile2 << "-> <" << listHead->Ni << ", " << listHead->Nj << ", " << listHead->edgeCost << "> ";
			listHead = listHead->next;
		}
		outFile2 << "-> <" << listHead->Ni << ", " << listHead->Nj << ", " << listHead->edgeCost << "> ";
		outFile2 << endl;
	}
	void printMST() {
		outFile1 << "A Kruskal's MST of the input graph is given below:" << endl;
		outFile1 << numNodes << endl;
		while (MSTofG->next != NULL) {
			outFile1 << MSTofG->Ni << " " << MSTofG->Nj << " " << MSTofG->edgeCost << endl;
			MSTofG = MSTofG->next;
		}
		outFile1 << "The total cost of a Kruskals MST is: " << totalMSTCost << endl;
	}

	void algorithm() {
		printSet(inWhichSet);
		int Ni, Nj, edgeCost;
		while (inFile >> Ni >> Nj >> edgeCost) {
			undirectedEdge* newEdge = new undirectedEdge(Ni, Nj, edgeCost);
			insertEdge(newEdge, edgeListHead);
			outFile2 << "listHead";
			printList(edgeListHead);
		}
		while (numSets != 1) {
			undirectedEdge*	nextEdge = removedEdge(edgeListHead);
			while (nextEdge->Ni == inWhichSet[nextEdge->Ni] && nextEdge->Nj == inWhichSet[nextEdge->Nj] || nextEdge->Ni == inWhichSet[inWhichSet[nextEdge->Nj]] && inWhichSet[nextEdge->Nj]>0)
				nextEdge = removedEdge(edgeListHead);
			pushEdge(nextEdge, MSTofG);
			totalMSTCost += nextEdge->edgeCost;
			merge2Sets(nextEdge->Ni, nextEdge->Nj);
			numSets--;
			printSet(inWhichSet);
			outFile2 << "MST";
			printMSTList(MSTofG);
		}
		printMST();
		inFile.close();
		outFile1.close();
		outFile2.close();
	}
};

int main(int argc, char** argv) {
	inFile.open(argv[1]);
	outFile1.open(argv[2]);
	outFile2.open(argv[3]);
	int n;
	inFile >> n;
	KruskalMST path(n);
	path.algorithm();
	system("pause");
}