#include <iostream>
#include <fstream>
#include <string>
using namespace std;
ifstream inFile;
ofstream outFile;
class node {
public:
	int colorID;
	node* next;

	node(int color) {
		colorID = color;
	}
};

class graphColoring {
public:
	int** adjacencyMatrix;
	int uncolorNode, newColor, numNode;
	node* usedColorTop=NULL;
	graphColoring(int size) {
		numNode = size;
		adjacencyMatrix = new int*[size+1];
		for (int i = 0; i <= numNode; i++)
			adjacencyMatrix[i] = new int[size+1];
		for (int i = 1; i <= numNode; i++) {
			for (int j = 1; j <= numNode; j++) {
				adjacencyMatrix[i][j] = 0;
			}
		}
	}

	void loadMatrix(int i, int j) {
		adjacencyMatrix[i][j] = 1;
		adjacencyMatrix[j][i] = 1;
	}

	int findUsedColor(int currentNode) {
		node* p = usedColorTop;
		while (p != NULL) {
			int useColor = p->colorID;
			if (checkAdjacent(useColor, currentNode) == 0)
				return useColor;
			p = p->next;
		}
		return 0;

	}

	void pushUsedColor(int newColor) {
		node* temp = new node(newColor);
		temp->next = usedColorTop;
		usedColorTop = temp;

	}

	int checkAdjacent(int color, int currentNode) {
		int used = 0;
		for (int i = 1; i <= numNode; i++) {
			if (adjacencyMatrix[currentNode][i] == 1 && i <= currentNode&&adjacencyMatrix[i][i] != color) {
				used = 0;
			}
			if (adjacencyMatrix[currentNode][i] == 1 && i <= currentNode&&adjacencyMatrix[i][i] == color) {
				return used = 1;
			}			
		}
		return used;
	}

	void printNewColor() {
		int count = 0;
		node* p = usedColorTop;
		while (p != NULL) {
			count++;
			p = p->next;
		}
		outFile <<"The number of colors used is: " << count << endl;

	}

	void printAdjacencyMatrix() {
		for (int i = 1; i <= numNode; i++) {
			for (int j = 1; j <= numNode; j++) 
				outFile << adjacencyMatrix[i][j]<< " ";
			outFile << endl;
		}
		outFile << endl << endl;
	}
};

int main(int argc, char**argv) {
	inFile.open(argv[1]);
	outFile.open(argv[2]);
	int numNode, newColor=0, currentNode=0, i, j;
	inFile >> numNode;
	graphColoring graph(numNode);
	while (inFile >> i >> j) {
		graph.loadMatrix(i, j);
	}

	while (currentNode<numNode) {
		currentNode++;
		graph.printAdjacencyMatrix();
		int usedColor = graph.findUsedColor(currentNode);
		if (usedColor > 0)
			graph.adjacencyMatrix[currentNode][currentNode] = usedColor;
		else {
			newColor++;
			graph.adjacencyMatrix[currentNode][currentNode] = newColor;
			graph.pushUsedColor(newColor);
		}
	}

	graph.printNewColor();
	graph.printAdjacencyMatrix();
	inFile.close();
	outFile.close();
}
