#include <iostream>
#include <string>
#include <fstream>
using namespace std;
struct listBinTreeNode {
	string chStr;
	int prob;
	listBinTreeNode *next;
	listBinTreeNode *left;
	listBinTreeNode *right;

	listBinTreeNode(string s, int p, listBinTreeNode* n, listBinTreeNode *l, listBinTreeNode *r) {
		chStr = s;
		prob = p;
		next = n;
		left = l;
		right = r;
	}

	listBinTreeNode(string s, int p) {
		chStr = s;
		prob = p;
		next = NULL;
		right = NULL;
		left = NULL;
	}

	listBinTreeNode() {}

	listBinTreeNode(string d, int p, listBinTreeNode *n) {
		chStr = d;
		prob = p;
		next = n;
	}

	string printNode(listBinTreeNode *T) {
		string null = "NULL";
		string s = "Print Node: ";
		s += "(" + T->chStr + ", " + to_string(T->prob) + ", ";
		if (T->next == NULL)
			s += null;
		else
			s += T->next->chStr;
		if (T->left == NULL)
			s += ", " + null;
		else
			s += ", " + T->left->chStr;
		if (T->right == NULL)
			s += ", " + null + ")\n";
		else
			s += ", " + T->right->chStr + ")\n";
		return s;
	}
};

class HuffmanLinkedList {
private:
	listBinTreeNode *oldListHead;
public:
	listBinTreeNode *listHead;

	int size = 0;
	HuffmanLinkedList() {
		oldListHead = new listBinTreeNode("dummy", NULL);
	}

	bool isEmpty() {
		return size == 0;
	}

	listBinTreeNode* getOldListHead() {
	   return  oldListHead;
	}

	string printList() {
		listBinTreeNode *p = oldListHead;
		string s = "";
		while (p->next != NULL) {
			s += "-->(" + p->chStr + ", "  + to_string(p->prob) + ", " + p->next->chStr + ")";
			p = p->next;
		}
		if (p->next == NULL)
			s += "-->(" + p->chStr + ", " + to_string(p->prob) + ", " +  "NULL)";

		return s;
	}

	void listInsert(listBinTreeNode *spot, listBinTreeNode *newNode){
		newNode->next=spot->next;
		spot->next=newNode;

	}

	listBinTreeNode* findSpot(int prob, listBinTreeNode *listhead) {
		listBinTreeNode *spot = listhead;
		while ((spot->next != NULL) && (spot->prob<prob)&& (spot->next->prob<prob)) {
			spot = spot->next;
		}
		return spot;
	}
};

class HuffmanBinaryTree {
private:
	listBinTreeNode *Root=NULL;
	listBinTreeNode *listHead;

public:
	HuffmanBinaryTree(listBinTreeNode *oldListHead) {
		listHead = oldListHead->next;
	}

	bool isLeaf(listBinTreeNode* T) {
		return (T->left==NULL&&T->right==NULL);
	}

	void charInfor(ofstream &out) {
		string code = "";
		string chStr;
		constructCharCode(Root, code, out);
	}

	void addTree(ofstream& outFile5) {
		HuffmanLinkedList list;	
		outFile5<<endl << printList(listHead) << endl;
		while (listHead->next != NULL) {
			listBinTreeNode* newNode=new listBinTreeNode();
			newNode->chStr = listHead->chStr + listHead->next->chStr;
			newNode->left = listHead;
			newNode->right = listHead->next;
			newNode->prob = listHead->prob + listHead->next->prob;
			newNode->next = NULL;
			listBinTreeNode print;
			outFile5 << print.printNode(newNode);
			if (newNode->prob != 100) {
				listBinTreeNode* spot=list.findSpot(newNode->prob, listHead);
				(list.listInsert(spot, newNode));
				listHead = listHead->next->next;
			}
			else {
				listHead=newNode;
			}		
			outFile5 << printList(listHead) << endl;
		}
		Root = listHead;
	}

	string printList(listBinTreeNode *listHead) {
		listBinTreeNode *p = listHead;
		string s = "listHead";
		while (p->next != NULL) {
			s += "-->(" + p->chStr + " " + to_string(p->prob) + ")";
			p = p->next;
		}
		if (p->next == NULL)
			s += "-->(" + p->chStr + " " + to_string(p->prob) + ")";
		return s;
	}

	void constructCharCode(listBinTreeNode *T, string code, ofstream &outFile1) {
		if (T == NULL)
			return;
		else if (isLeaf(T)) {
			outFile1<< (T->chStr + " ");
			outFile1<< (code + "\n");
		}
		else {
			constructCharCode(T->left, code + "0", outFile1);
			constructCharCode(T->right, code + "1", outFile1);
		}
	}

	void preOrderTraveral(listBinTreeNode *T, ofstream &outFile2) {
		if (T == NULL)
			return;
		else {
			listBinTreeNode print;
			outFile2 <<print.printNode(T);
			preOrderTraveral(T->left, outFile2);
			preOrderTraveral(T->right, outFile2);
		}
	}

	listBinTreeNode getRoot() {
		return *Root;
	}

	void inOrderTraveral(listBinTreeNode *T, ofstream& outFile3)  {
		if (T == NULL)
			return;
		else {
			inOrderTraveral(T->left, outFile3);
			listBinTreeNode print;
			outFile3<<print.printNode(T);
			inOrderTraveral(T->right, outFile3);
		}
	}
	void postOrderTraveral(listBinTreeNode *T, ofstream& outFile4) {
		if (T == NULL)
			return;
		else {
			postOrderTraveral(T->left, outFile4);
			postOrderTraveral(T->right, outFile4);
			listBinTreeNode print;
			outFile4<<print.printNode(T);
		}
	}
};

int main(int argc, char** argv) {
	HuffmanLinkedList list;
	ifstream inFile;
	ofstream outFile1, outFile2,outFile3, outFile4, outFile5;
	inFile.open(argv[1]);
	outFile1.open(argv[2]);
	outFile1 <<("constructCharCode:\n");
	outFile2.open(argv[3]);
	outFile2<< ("preOrderTraveral:\n");
	outFile3.open(argv[4]);
	outFile3<< ("inOrderTraveral:\n");
	outFile4.open(argv[5]);
	outFile4 << ("postOrderTraveral:\n");
	outFile5.open(argv[6]);
	outFile5 << ("For debugging outputs:\n");
	string chara;
	int p;
	listBinTreeNode *head = list.getOldListHead();
	while (inFile >> chara) {
		inFile >> p;
		outFile5 << "Insert(" << chara << " " << p << "):" << endl;
		listBinTreeNode* newNode = new listBinTreeNode(chara, p);
		listBinTreeNode *spot=list.findSpot(p, head);
		list.listInsert(spot, newNode);
		outFile5 << "oldListHead" << list.printList() << endl;
	}
	
	HuffmanBinaryTree tree= HuffmanBinaryTree(head);
	tree.addTree(outFile5);
	tree.charInfor(outFile1);
	tree.preOrderTraveral(&tree.getRoot(), outFile2);
	tree.inOrderTraveral(&tree.getRoot(), outFile3);
	tree.postOrderTraveral(&tree.getRoot(), outFile4);
	outFile1.close();
	outFile2.close();
	outFile3.close();
	outFile4.close();
	outFile5.close();
	inFile.close();
	system("pause");
	return 0;
}