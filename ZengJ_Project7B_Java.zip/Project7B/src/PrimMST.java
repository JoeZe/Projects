import java.io.FileWriter;
import java.io.IOException;
public class PrimMST {
   int numNodes,numSets,totalMSTCost=0;
   int inWhichSet[];
   private undirectedEdge MSTofG;
   private undirectedEdge edgeListHead;
   int graphNodeArray[];
   graphNode setA;
   graphNode setB;
   PrimMST(int N) {
      numNodes = N;
      inWhichSet = new int[N + 1];
      graphNodeArray = new int[N + 1];
      numSets = N;
      MSTofG = new undirectedEdge(0, 0, 0);
      edgeListHead = new undirectedEdge(0, 0, 0); 
      for (int i = 0; i <= N; i++) {
         graphNodeArray[i] = 0;
      }
      for (int i = 0; i <= N; i++) {
         if(i==1)
            inWhichSet[i] = 1;
         else
            inWhichSet[i]=2;
      }
   }

   public undirectedEdge getEdgeListHead(){
      return edgeListHead;
   }
   public void insertEdge(undirectedEdge edge, undirectedEdge edgeListHead) {
      undirectedEdge walker1 = edgeListHead;
      undirectedEdge walker2 = edgeListHead.next;
      while ((walker1.next != null) && (walker2.edgeCost<edge.edgeCost)) {
         walker1 = walker1.next;
         walker2 = walker2.next;
      }
      edge.next = walker2;
      walker1.next = edge; 
   }

   public undirectedEdge removedEdge(undirectedEdge edgeListHead) {
      edgeListHead=edgeListHead.next;
      return edgeListHead;    
   }

   public void pushEdge(undirectedEdge edge, undirectedEdge MSTofG) {
      edge.next = MSTofG;
      this.MSTofG= edge;
   }

   public void move2SetA(int node) {
         inWhichSet[node] = 1;
   }

   public void printSet(int[] inWhichSet, FileWriter outPut2) throws IOException {
      outPut2.write("InWhichSet: "); 
      for (int i = 1; i <= numNodes; i++)
         outPut2.write(inWhichSet[i] + " ");
      outPut2.write("\r\n");
   }

   public void printList(undirectedEdge edgeListHead, FileWriter outPut2) throws IOException {
      undirectedEdge listHead=edgeListHead;
      while (listHead.next != null) {
         outPut2.write("-> <" +listHead.Ni + ", "+ listHead.Nj + ", " + listHead.edgeCost + "> "); 
         listHead = listHead.next;
      }
      outPut2.write("-> <" +listHead.Ni + ", "+ listHead.Nj + ", " + listHead.edgeCost + "> "+"\r\n");
   }

   public void printMSTList(undirectedEdge edgeListHead, FileWriter outPut2) throws IOException {
      undirectedEdge listHead=edgeListHead;
      int i=1;
      while (listHead.next != null&&i<=10) {
         outPut2.write("-> <" +listHead.Ni + ", "+ listHead.Nj + ", " + listHead.edgeCost + "> "); 
         listHead = listHead.next;
         i++;
      }
      outPut2.write("-> <" +listHead.Ni + ", "+ listHead.Nj + ", " + listHead.edgeCost + "> "+"\r\n");
   }
   
   public void printMST(FileWriter outPut1) throws IOException {
      outPut1.write("A Prim's MST of the input graph is given below:"+"\r\n");
      outPut1.write(numNodes+"\r\n");
      undirectedEdge p=MSTofG;
      while (p.next != null) {
         outPut1.write(p.Ni + " " + p.Nj + " " + p.edgeCost +"\r\n");
         p = p.next;
      }
      outPut1.write("The total cost of a Prim'S MST is: " + totalMSTCost+"\r\n");
   }

   public void algorithm(FileWriter outPut1, FileWriter outPut2) throws IOException {     
      printSet(inWhichSet, outPut2);
      undirectedEdge walker=edgeListHead;
      while(walker!=null&&isSetBEmpty()){
         undirectedEdge nextEdge = removedEdge(walker);
         while((!isInSetA(nextEdge.Ni)&&!isInSetA(nextEdge.Nj))||(!isInSetB(nextEdge.Nj)&&!isInSetB(nextEdge.Ni))){           
            nextEdge = nextEdge.next;
         }
         undirectedEdge newEdge=new undirectedEdge(nextEdge.Ni,nextEdge.Nj,nextEdge.edgeCost);
         pushEdge(newEdge, MSTofG);
         totalMSTCost += nextEdge.edgeCost;
         if(isInSetA(nextEdge.Ni)){
            move2SetA(nextEdge.Nj);
         }
         else
            move2SetA(nextEdge.Ni);
         printSet(inWhichSet, outPut2);
         outPut2.write("MST") ;
         printMSTList(MSTofG, outPut2);

      }
      printMST(outPut1);
   }
   
 
   public boolean isInSetA(int node){
      if(inWhichSet[node]==1)
         return true;
      return false;
      
   }
   
   public boolean isInSetB(int node){
      if(inWhichSet[node]==2)
         return true;
      return false;
   }
   
   public boolean isSetBEmpty(){
      for(int i= 2; i<=numNodes; i++){
         if(inWhichSet[i]==2)
            return true;
      }
      return false;
   }
}


