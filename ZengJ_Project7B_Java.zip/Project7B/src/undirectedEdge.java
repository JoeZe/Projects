
public class undirectedEdge {
   int Ni, Nj, edgeCost;
   undirectedEdge next;

   void printEdge() {

   }

   public undirectedEdge(int i, int j, int data) {
       Ni = i;
       Nj = j;
       edgeCost = data;
       next = null;
   }



}
