import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Project7 {
   public static FileWriter outPut1;
   public static FileWriter outPut2;
   public static void main(String[] args) throws IOException{
      int n, Ni, Nj, edgeCost;
      try {
         Scanner inFile=new Scanner(new FileReader(args[0]));
         FileWriter outPut1=new FileWriter(args[1]);
         FileWriter outPut2=new FileWriter(args[2]);
         n=inFile.nextInt();
         PrimMST path= new PrimMST(n);
         while(inFile.hasNext()){
            Ni=inFile.nextInt();
            Nj=inFile.nextInt();
            edgeCost=inFile.nextInt(); 
            undirectedEdge newEdge = new undirectedEdge(Ni, Nj, edgeCost);
            path.insertEdge(newEdge, path.getEdgeListHead());
            outPut2.write("listHead");
            path.printList(path.getEdgeListHead(), outPut2);
         }
         
         path.algorithm(outPut1, outPut2);
         inFile.close();
         outPut1.close();
         outPut2.close();
         System.exit(0);
         
      } catch (FileNotFoundException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }
   }
}
