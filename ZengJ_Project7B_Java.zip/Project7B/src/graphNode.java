
public class graphNode {
   int nodeId;
   graphNode next;

   public graphNode(int node) {
       nodeId = node;
       next = null;

   }
   

}
