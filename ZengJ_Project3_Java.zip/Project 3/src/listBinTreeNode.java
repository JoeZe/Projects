public class listBinTreeNode{
   String chStr;
   int prob;
   listBinTreeNode next;
   listBinTreeNode left;
   listBinTreeNode right;
      
   public listBinTreeNode(String s, int p, listBinTreeNode l,listBinTreeNode r){
      chStr=s;
      prob=p;
      left=l;
      right=r;
   }
   public listBinTreeNode(String d, int p){
      chStr=d;
      prob=p;
      next=null;
   }
      
   public listBinTreeNode(String d, int p, listBinTreeNode n){
      chStr=d;
      prob=p;
      next=n;
   }
   
   public static String printNode(listBinTreeNode T){
      String s="printNode: ";
      s += "(" + T.chStr + ", " + T.prob + ", ";
      if (T.next == null)
          s += null;
      else
          s += T.next.chStr;
      if (T.left == null)
          s += ", " + null;
      else
          s += ", " + T.left.chStr;
      if (T.right == null)
          s += ", " + null + ")\r\n";
      else
          s += ", " + T.right.chStr + ")\r\n";
      return s;
   }
}