import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Project3 {
   public static FileWriter outFile2, outFile1, outFile3, outFile4, outFile5;
   public static void main(String[] args) throws IOException{
      HuffmanLinkedList list=new HuffmanLinkedList();
      HuffmanBinaryTree tree=new HuffmanBinaryTree();
      try {
      Scanner inFile= new Scanner(new FileReader(args[0]));//HuffmanCoding_Data.txt outFile1.txt outFile2.txt outFile3.txt outFile4.txt outFile5.txt
      outFile1=new FileWriter(args[1]);
      outFile1.write("constructCharCode:\r\n");
      outFile2=new FileWriter(args[2]);
      outFile2.write("preOrderTraveral:\r\n");
      outFile3=new FileWriter(args[3]);
      outFile3.write("inOrderTraveral:\r\n");
      outFile4=new FileWriter(args[4]);
      outFile4.write("postOrderTraveral:\r\n");
      outFile5=new FileWriter(args[5]);
      outFile5.write("For debugging outputs:\r\n");
      while(inFile.hasNext()){
         String s=inFile.next();
         int p=inFile.nextInt();
         listBinTreeNode newNode=new listBinTreeNode(s, p);
         list.listInsert(list.findSpot(p), newNode);
         outFile5.write("Insert(" + s +" "+ p+"):\r\n");
         outFile5.write("oldListHead" +list.printList()+"\r\n");
      }
      
      tree.addTree();
      tree.charInfor();
      tree.preOrderTraveral(tree.getRoot());
      tree.inOrderTraveral(tree.getRoot());
      tree.postOrderTraveral(tree.getRoot());
      inFile.close();
      outFile1.close();
      outFile2.close();
      outFile3.close();
      outFile4.close();
      outFile5.close();
   } catch (FileNotFoundException e) {
      e.printStackTrace();
   }catch (IndexOutOfBoundsException e){
      e.printStackTrace();
      }
   }
}
