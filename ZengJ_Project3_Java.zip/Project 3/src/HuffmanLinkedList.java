import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class HuffmanLinkedList {
   private static int size=0;
   private static listBinTreeNode oldListHead;
   private static listBinTreeNode listHead;
   
   public HuffmanLinkedList() {
      oldListHead=new listBinTreeNode("dummy", 0, null);
   }
   
   public boolean isEmpty(){
      return size==0;
   }
   
   public static listBinTreeNode getOldListHead(){
      return listHead=oldListHead.next;
   }
     
   public String printList(){
      listBinTreeNode p=oldListHead;
      String s="";
      while(p.next!=null){
         s+="-->(" + p.chStr +", "+ p.prob + ", "+ p.next.chStr + ")";
         p=p.next;
      }
      if(p.next==null)
         s+="-->(" + p.chStr +", "+ p.prob + ", " + p.next +")";
      return s;
   }//print List
   
   public static void listInsert(listBinTreeNode spot, listBinTreeNode newNode){
      newNode.next=spot.next;
      spot.next=newNode;
   }//list Insert

   public static listBinTreeNode findSpot(int prob) {
      listBinTreeNode spot=oldListHead;
      while((spot.next!=null)&&(spot.prob<prob)&&spot.next.prob<prob){
         spot=spot.next;
      }
      size++;
      return spot;
   }//find spot
}

