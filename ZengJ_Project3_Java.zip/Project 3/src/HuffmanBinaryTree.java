import java.io.FileWriter;
import java.io.IOException;

public class HuffmanBinaryTree {
   private listBinTreeNode Root=null;
   public HuffmanBinaryTree(){}
   public void charInfor() throws IOException{
      String code="";
      String chStr;
      int prob;
      constructCharCode(Root, code);
   }
    
   public boolean isLeaf(listBinTreeNode T){
      return (T.left==null&&T.right==null);
   }

   public void addTree() throws IOException{
      listBinTreeNode listHead=HuffmanLinkedList.getOldListHead();
      Project3.outFile5.write("\r\n"+printList(listHead));
      while(listHead.next!=null){
         listBinTreeNode newNode=new listBinTreeNode(null, 0, null, null);;
         newNode.chStr=listHead.chStr+listHead.next.chStr;
         newNode.left=listHead;
         newNode.right=listHead.next;
         newNode.prob=listHead.prob+listHead.next.prob; 
         Project3.outFile5.write(listBinTreeNode.printNode(newNode));
         if(newNode.prob!=100){
            HuffmanLinkedList.listInsert(HuffmanLinkedList.findSpot(newNode.prob), newNode); 
            listHead=listHead.next.next;
         }
         else
            listHead=newNode;
         Project3.outFile5.write(printList(listHead));   
      }
      Root=listHead;
   }//addTree
   
   private String printList(listBinTreeNode listHead) {
      listBinTreeNode p=listHead;
      String s="listHead";
      while(p.next!=null){
         s+="-->(" + p.chStr +" "+ p.prob + ")";
         p=p.next;
      }
      if(p.next==null)
         s+="-->(" + p.chStr +" "+ p.prob +")\r\n";
      return s;
   }//printlist
   
   public void constructCharCode(listBinTreeNode T, String code) throws IOException{
      if(T ==null)
         return;
      else if(isLeaf(T)){
         Project3.outFile1.write(T.chStr+" ");
         Project3.outFile1.write(code+"\r\n");
      }
      else{
         constructCharCode(T.left, code+"0");
         constructCharCode(T.right, code+"1");
      }
   }//constructcharcode

   public void preOrderTraveral(listBinTreeNode T) throws IOException {
      if(T==null)
         return;
      else{
         Project3.outFile2.write(listBinTreeNode.printNode(T));
         preOrderTraveral(T.left);
         preOrderTraveral(T.right);
      }
   }//preorder
   
   public listBinTreeNode getRoot() {
      return Root;
   }//getRoot
   
   public void inOrderTraveral(listBinTreeNode T) throws IOException {
      if(T==null)
         return;
      else{
         inOrderTraveral(T.left);
         Project3.outFile3.write(listBinTreeNode.printNode(T));
         inOrderTraveral(T.right);
      }  
   }//inorder
   
   public void postOrderTraveral(listBinTreeNode T) throws IOException {
      if(T==null)
         return;
      else{
         postOrderTraveral(T.left);
         postOrderTraveral(T.right);
         Project3.outFile4.write(listBinTreeNode.printNode(T));
      }
   }//post 
}//HuffmanBinaryTree class
