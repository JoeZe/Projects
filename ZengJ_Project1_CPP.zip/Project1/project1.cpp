#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class linkedList {
	struct listNode {
		string data;
		listNode *next;

		listNode(string d) {
			data = d;
			next = NULL;
		}

		listNode(string d, listNode *n) {
			data = d;
			next = n;
		}
	};
private:
	listNode *listHead;
	int size = 0;

public:
	linkedList() {
		listHead = new listNode("dummy", NULL);
	}

	bool isEmpty() {
		return size == 0;
	}

	string printList() {
		listNode *p = listHead;
		string s = "";
		for (int i = 0; i<15; i++) {
			if (p->next != NULL) {
				s += "-->(" + p->data + ", " + p->next->data + ")";
				p = p->next;
			}
		}
		if (p->next == NULL)
			s += "-->(" + p->data + ", NULL)";
		return s;
	}

	void listInsert(string s) {
		listNode* newElement = new listNode(s);
		listNode* walker1 = listHead;
		listNode* walker2 = listHead->next;
		while ((walker1->next != NULL) && ((walker2->data.compare(s))<0)) {
			walker1 = walker1->next;
			walker2 = walker2->next;
		}
		if (listHead == NULL) {
			newElement->next = walker2;
			walker1->next = newElement;
		}
		else {
			newElement->next = walker2;
			walker1->next = newElement;
		}
		size++;
	}


};

int main(int argc, char** argv) {
	linkedList list;
	cout << "listHead" << list.printList() << endl;
	ifstream inFile;
	inFile.open(argv[1]);
	string word;
	while (inFile >> word) {
		cout << "Insert(" << word << "):" << endl;
		list.listInsert(word);
		cout << "listHead" << list.printList() << endl;
	}

	inFile.close();

	return 0;
}
