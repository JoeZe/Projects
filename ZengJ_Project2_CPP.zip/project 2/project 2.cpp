#include <iostream>
#include <fstream>
#include <string>
using namespace std;
void printAry(int index, int charCounts[], char charIn, ofstream& output){
	index=0;
	while(index<256){
		if(charCounts[index]>0){
			charIn=(char) index;
			output<<"char " << charIn <<": " << charCounts[index] << " count\n";
		}
		index++;		
	}
}

int main(int argc, char** argv){
	ifstream inFile;
	ofstream output;
	char charIn=0;
	int index=0;
	int charCounts[256]={0};
	string word;
	inFile.open(argv[1]);
	output.open(argv[2]);
	while(inFile>>word){
		for(int i=0; i< word.length();i++){
			charIn=word[i];
			index=(int) charIn;
			for(int j=0; j<256;j++)
				if(index==j)
					charCounts[index]++;	
		}
	}
	printAry(index, charCounts, charIn, output);
	inFile.close();
	output.close();
	return 0;
}
